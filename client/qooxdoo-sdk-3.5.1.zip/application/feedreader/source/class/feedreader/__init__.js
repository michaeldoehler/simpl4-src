/**
 * Feed reader demo application
 */