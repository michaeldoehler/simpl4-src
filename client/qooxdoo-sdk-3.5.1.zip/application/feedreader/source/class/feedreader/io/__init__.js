/**
 * This package contains functionality to download and parse feed data from the
 * internet.
 */