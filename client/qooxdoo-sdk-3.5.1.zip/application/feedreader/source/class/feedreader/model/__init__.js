/**
 * This package contains the feed reader's data model.
 */
