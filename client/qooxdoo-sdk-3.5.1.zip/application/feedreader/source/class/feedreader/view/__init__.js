/**
 * This package contains the feedreader's UI parts
 */