/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("fce.theme.Color",
{
  extend : qx.theme.indigo.Color,

  colors :
  {
  }
});