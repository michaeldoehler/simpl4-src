/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("fce.theme.Theme",
{
  meta :
  {
    color : fce.theme.Color,
    decoration : fce.theme.Decoration,
    font : fce.theme.Font,
    icon : qx.theme.icon.Tango,
    appearance : fce.theme.Appearance
  }
});