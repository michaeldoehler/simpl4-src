/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("fce.theme.Font",
{
  extend : qx.theme.indigo.Font,

  fonts :
  {
    "bigger" :
    {
      include : ["bold"],
      size: 13
    }
  }
});