/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("fce.theme.Decoration",
{
  extend : qx.theme.indigo.Decoration,

  decorations :
  {
  }
});