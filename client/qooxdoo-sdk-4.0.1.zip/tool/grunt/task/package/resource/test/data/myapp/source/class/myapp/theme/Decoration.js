/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("myapp.theme.Decoration",
{
  extend : qx.theme.modern.Decoration,

  decorations :
  {
  }
});