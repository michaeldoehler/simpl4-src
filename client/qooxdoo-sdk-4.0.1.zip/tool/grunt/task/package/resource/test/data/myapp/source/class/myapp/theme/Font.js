/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("myapp.theme.Font",
{
  extend : qx.theme.modern.Font,

  fonts :
  {
  }
});