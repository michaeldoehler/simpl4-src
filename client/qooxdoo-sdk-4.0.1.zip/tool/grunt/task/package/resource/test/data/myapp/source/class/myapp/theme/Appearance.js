/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("myapp.theme.Appearance",
{
  extend : qx.theme.modern.Appearance,

  appearances :
  {
  }
});