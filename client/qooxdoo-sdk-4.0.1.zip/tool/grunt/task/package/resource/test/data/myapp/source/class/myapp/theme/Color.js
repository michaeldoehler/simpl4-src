/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("myapp.theme.Color",
{
  extend : qx.theme.modern.Color,

  colors :
  {
  }
});